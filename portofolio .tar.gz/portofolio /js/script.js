$(document).ready(function(){
      // Add smooth scrolling to all links
  $(".page-scroll").on('click', function(event) {

    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var elementujuan = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(elementujuan).offset().top -55
      }, 900);
    } // End if

    });

    // membuat paralax
    

    $(window).scroll(function(){
      var wscroll = $(this).scrollTop();
      
      //jumbotron
      $('.jumbotron img').css({
        'transform' : 'translate(0px,'+ wscroll/4+'%)'
      });

      $('.jumbotron h1').css({
        'transform' : 'translate(0px,'+ wscroll/2+'%)'
      });

      $('.jumbotron p').css({
        'transform' : 'translate(0px,'+ wscroll/1.2+'%)'
      });

      // portofolio
      if(wscroll > $('.portofolio').offset().top -350){
        $('.portofolio .thumbnail').each(function(i){
          setTimeout(function(){
            $('.portofolio .thumbnail').eq(i).addClass('muncul');
          },300 * (i+1));
        }); 
      }

      // about
      if(wscroll > $('.about').offset().top -450 ){
      $('.pkiri').addClass('pmuncul');
      $('.pkanan').addClass('pmuncul');
      }

    });

});
